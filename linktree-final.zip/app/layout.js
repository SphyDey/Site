import './globals.css';

export const metadata = {
  title: 'Linktree Clone',
  description: 'Multi-user link-in-bio app',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}