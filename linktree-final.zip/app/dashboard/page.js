"use client";

import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabase";

export default function Dashboard() {
  const [session, setSession] = useState(null);
  const [username, setUsername] = useState("");
  const [links, setLinks] = useState([]);
  const [newTitle, setNewTitle] = useState("");
  const [newUrl, setNewUrl] = useState("");

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session) {
        loadProfile(data.session.user.id);
        loadLinks(data.session.user.id);
      }
    });

    const { data: listener } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        if (session) {
          loadProfile(session.user.id);
          loadLinks(session.user.id);
        }
      }
    );

    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadProfile(userId) {
    let { data } = await supabase
      .from("profiles")
      .select("username")
      .eq("id", userId)
      .single();
    if (data) setUsername(data.username || "");
  }

  async function saveProfile() {
    if (!session) return;
    await supabase.from("profiles").update({
      username,
      updated_at: new Date(),
    }).eq("id", session.user.id);
    alert("Profile updated!");
  }

  async function loadLinks(userId) {
    let { data } = await supabase
      .from("links")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });
    if (data) setLinks(data);
  }

  async function addLink() {
    if (!session) return;
    await supabase.from("links").insert({
      user_id: session.user.id,
      title: newTitle,
      url: newUrl,
    });
    setNewTitle("");
    setNewUrl("");
    loadLinks(session.user.id);
  }

  async function deleteLink(id) {
    await supabase.from("links").delete().eq("id", id);
    loadLinks(session.user.id);
  }

  if (!session) return <p className="text-center mt-10">Please log in first.</p>;

  return (
    <div className="max-w-md mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>

      <h2 className="text-xl mb-2">Edit Profile</h2>
      <input
        type="text"
        placeholder="Username"
        className="w-full border p-2 rounded mb-2"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <button
        onClick={saveProfile}
        className="bg-blue-500 text-white px-4 py-2 rounded mb-4"
      >
        Save Profile
      </button>

      <h2 className="text-xl mb-2">Your Links</h2>
      <input
        type="text"
        placeholder="Link title"
        className="w-full border p-2 rounded mb-2"
        value={newTitle}
        onChange={(e) => setNewTitle(e.target.value)}
      />
      <input
        type="text"
        placeholder="https://example.com"
        className="w-full border p-2 rounded mb-2"
        value={newUrl}
        onChange={(e) => setNewUrl(e.target.value)}
      />
      <button
        onClick={addLink}
        className="bg-green-500 text-white px-4 py-2 rounded mb-4"
      >
        Add Link
      </button>

      <ul>
        {links.map((link) => (
          <li key={link.id} className="flex justify-between items-center mb-2">
            <a
              href={link.url}
              target="_blank"
              className="text-blue-600 underline"
            >
              {link.title}
            </a>
            <button
              onClick={() => deleteLink(link.id)}
              className="text-red-500 ml-2"
            >
              ❌
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}