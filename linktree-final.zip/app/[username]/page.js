import { supabase } from "../../lib/supabase";

export default async function UserPage({ params }) {
  const { username } = params;

  let { data: profile } = await supabase
    .from("profiles")
    .select("id, username")
    .eq("username", username)
    .single();

  if (!profile) return <p className="text-center mt-10">User not found</p>;

  let { data: links } = await supabase
    .from("links")
    .select("title, url")
    .eq("user_id", profile.id)
    .order("created_at", { ascending: false });

  return (
    <div className="flex flex-col items-center p-6">
      <h1 className="text-3xl font-bold mb-6">@{profile.username}</h1>
      <div className="space-y-4 w-full max-w-md">
        {links?.map((link) => (
          <a
            key={link.url}
            href={link.url}
            target="_blank"
            className="block bg-white shadow rounded-lg p-4 text-center text-blue-600 hover:bg-gray-100"
          >
            {link.title}
          </a>
        ))}
      </div>
    </div>
  );
}